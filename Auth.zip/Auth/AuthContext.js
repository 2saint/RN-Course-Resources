import { createContext, useContext, useMemo } from "react";
import { AuthDispatch } from "./AuthState";

export const AuthContext = createContext({
  signIn: () => {},
  signOut: () => {},
});

export default function AuthContextProvider({ children }) {
  const dispatch = useContext(AuthDispatch);

  const authContext = useMemo(
    () => ({
      signIn: async (data) => {
        dispatch({ type: "SIGN_IN", token: "dummy-auth" });
      },
      signOut: () => dispatch({ type: "SIGN_OUT" }),
      signUp: async (data) => {
        dispatch({ type: "SIGN_UP", token: "dummy-auth" });
      },
    }),
    []
  );
  return (
    <AuthContext.Provider value={authContext}>{children}</AuthContext.Provider>
  );
}
