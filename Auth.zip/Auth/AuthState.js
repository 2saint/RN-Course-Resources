import { createContext } from "react";

export const AuthDispatch = createContext(null);
