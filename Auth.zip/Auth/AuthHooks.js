import { createContext, useContext } from "react";

export const SignInContext = createContext();

export function useIsSignedIn() {
  const isSignedIn = useContext(SignInContext);
  return isSignedIn;
}

export function useIsSignedOut() {
  const isSignedIn = useContext(SignInContext);
  return !isSignedIn;
}
